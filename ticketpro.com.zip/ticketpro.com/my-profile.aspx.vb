﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IdentityModel.Metadata
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Runtime.Remoting.Lifetime

Partial Class my_profile
    Inherits System.Web.UI.Page

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("userid") = "" Then
                    Response.Redirect("default.aspx")
                End If

                ' Update session details for the current users 
                ' So that When the user ligin next time, they can continue where they left.
                Dim SesDate As String = Format(Now, "yyyy-MM-dd")
                conn.Open()
                ds = New Data.DataSet
                da = New SqlDataAdapter("Insert into Session_mgmt (Username, UserType, url_name, LogDate) values ('" & Session("userid") & "','" & Session("usertype") & "','my-profile.aspx','" & SesDate & "')", conn)
                da.Fill(ds, "Session_mgmt")
                conn.Close()


                Panel1.Visible = False
                Panel2.Visible = False

                Bind_Data()

            End If

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub
    Sub Bind_Data()
        conn.Open()
        PCMD.Connection = conn
        PCMD.CommandText = "Select * from Account Where UserName='" & Session("userid") & "'"
        PDR = PCMD.ExecuteReader
        If PDR.HasRows = False Then
            Panel1_on()
            lberr.Text = "Given User Name Not Found..."
            PDR.Close()
            conn.Close()
            Exit Sub
        Else
            PDR.Read()
            'Name, UserName, Password, Email, CreationDate, LastLogin, NoOfLogin, Utype, UStatus, StaffID
            tbuser.Text = PDR.Item("UserName")
            tbname.Text = PDR.Item("Name")
            tbusts.Text = PDR.Item("UStatus")
            tbutype.Text = PDR.Item("Utype")
            tbemail.Text = PDR.Item("Email")
            tbcompany.Text = PDR.Item("company")
            tbstaffid.Text = PDR.Item("Unique_id")
            tblastlogin.Text = PDR.Item("LastLogin")
            If IsDBNull(PDR.Item("avatar")) Then
                imgavatar.ImageUrl = "assets\icons\profile.png"
            Else
                imgavatar.ImageUrl = PDR.Item("avatar")
            End If


        End If
        PDR.Close()
        conn.Close()

        ' decrypt the email and display


    End Sub

    Sub Panel1_on()
        Panel1.Visible = True
        Panel2.Visible = False
    End Sub
    Sub Panel2_on()
        Panel1.Visible = False
        Panel2.Visible = True
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            If pi1.FileName = "" Then
                lberr.Text = "Please Select Avatar Image to continue..."
                Panel1_on()
                Exit Sub
            End If

            Dim Fname As String
            ' for 1st image
            If pi1.PostedFile.FileName <> "" Then 'Check to make sure we actually have a file to upload
                Generate_FileID()
                If pi1.PostedFile.ContentLength <= 1024000 Then
                    Fname = "user_avatar/" & lbfname.Text & pi1.FileName
                    pi1.SaveAs(Server.MapPath("user_avatar/" & lbfname.Text & pi1.FileName))
                    conn.Open()
                    ds = New Data.DataSet
                    da = New SqlDataAdapter("Update Account set Avatar='" & Fname & "' Where UserName='" & Session("userid") & "'", conn)
                    da.Fill(ds, "Account")
                    conn.Close()
                Else
                    lberr.Text = "The selected image file size more than 1 MB, Kindly choose the smaller on or reduce the file size and try again..."
                    Panel1_on()

                    Exit Sub
                End If
            End If

            Bind_Data()

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Generate_FileID()
        Dim Y, M, D, MI, Hou, S As String
        Dim OrderNo As String
        ' Generate order id
        Y = Format(Now, "yyyy")         ' year
        M = Format(Now, "MM")           ' month
        D = Format(Now, "dd")           ' date                
        MI = Format(Now, "mm")          ' minute
        Hou = Format(Now, "HH")          ' Hour
        S = Format(Now, "ss")           ' second
        OrderNo = Y & M & D & Hou & MI & S
        lbfname.Text = OrderNo
    End Sub
End Class
