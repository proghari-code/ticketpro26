﻿
Partial Class ticket_details
    Inherits System.Web.UI.Page

End Class
