﻿
Partial Class dashboard
    Inherits System.Web.UI.Page

    Private Sub dashboard_Load(sender As Object, e As EventArgs) Handles Me.Load
        lbdate.Text = Format(Now, "dd, MMMM, yyyy")
        imstatus.ImageUrl = "assets/images/good.png"
    End Sub
End Class
