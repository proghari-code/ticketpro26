﻿
Partial Class assign_ticket
    Inherits System.Web.UI.Page

End Class
