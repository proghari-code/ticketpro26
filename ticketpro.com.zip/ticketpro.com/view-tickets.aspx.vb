﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.EnterpriseServices
Imports System.IO

Partial Class view_tickets
    Inherits System.Web.UI.Page

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("userid") = "" Then
                    Response.Redirect("default.aspx")
                End If

                ' Update session details for the current users 
                ' So that When the user ligin next time, they can continue where they left.
                Dim SesDate As String = Format(Now, "yyyy-MM-dd")
                conn.Open()
                ds = New Data.DataSet
                da = New SqlDataAdapter("Insert into Session_mgmt (Username, UserType, url_name, LogDate) values ('" & Session("userid") & "','" & Session("usertype") & "','view-tickets.aspx','" & SesDate & "')", conn)
                da.Fill(ds, "Session_mgmt")
                conn.Close()

                Panel1.Visible = False
                Panel2.Visible = False

                tbfd.Text = Format(Now, "yyyy-MM-dd")
                tbsd.Text = Format(Now, "yyyy-MM-dd")

                Ticket_Data()
            End If

        Catch ex As Exception
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Ticket_Data()
        Dim TS As String = Request.QueryString("sts")
        conn.Open()
        ds = New Data.DataSet
        Dim UType As String
        UType = Session("usertype").ToString

        If TS = "" Then
            If UType <> "CLIENT" Then
                If tbsearch.Text = "" Then
                    da = New SqlDataAdapter("Select TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status from Tickets where (Date between '" & tbfd.Text & "' and '" & tbsd.Text & "') order by Date desc, Client", conn)
                Else
                    da = New SqlDataAdapter("Select TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status from Tickets where (Date between '" & tbfd.Text & "' and '" & tbsd.Text & "') and Client like'%" & tbsearch.Text & "%' or Date like'%" & tbsearch.Text & "%' or Remarks like'%" & tbsearch.Text & "%' or Priority like'%" & tbsearch.Text & "%' or Status like'%" & tbsearch.Text & "%' order by Date desc, Client", conn)
                End If
            Else
                If tbsearch.Text = "" Then
                    da = New SqlDataAdapter("Select TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status from Tickets where (Date between '" & tbfd.Text & "' and '" & tbsd.Text & "') and Client='" & Session("company") & "' order by Date desc, Client", conn)
                Else
                    da = New SqlDataAdapter("Select TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status from Tickets where (Date between '" & tbfd.Text & "' and '" & tbsd.Text & "') and Client='" & Session("company") & "'or Remarks like'%" & tbsearch.Text & "%' or Priority like'%" & tbsearch.Text & "%' or Status like'%" & tbsearch.Text & "%' order by Date desc, Client", conn)
                End If
            End If
        Else
            If UType <> "CLIENT" Then
                If tbsearch.Text = "" Then
                    da = New SqlDataAdapter("Select TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status from Tickets where Status ='" & TS & "' and (Date between '" & tbfd.Text & "' and '" & tbsd.Text & "') order by Date desc, Client", conn)
                Else
                    da = New SqlDataAdapter("Select TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status from Tickets where Status ='" & TS & "' and (Date between '" & tbfd.Text & "' and '" & tbsd.Text & "') and Client like'%" & tbsearch.Text & "%' or Remarks like'%" & tbsearch.Text & "%' or Priority like'%" & tbsearch.Text & "%' or Status like'%" & tbsearch.Text & "%' order by Date desc, Client", conn)
                End If
            Else
                If tbsearch.Text = "" Then
                    da = New SqlDataAdapter("Select TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status from Tickets where Status ='" & TS & "' and (Date between '" & tbfd.Text & "' and '" & tbsd.Text & "') and Client='" & Session("company") & "' order by Date desc, Client", conn)
                Else
                    da = New SqlDataAdapter("Select TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status from Tickets where Status ='" & TS & "' and (Date between '" & tbfd.Text & "' and '" & tbsd.Text & "') and Client='" & Session("company") & "' or Remarks like'%" & tbsearch.Text & "%' or Priority like'%" & tbsearch.Text & "%' or Status like'%" & tbsearch.Text & "%' order by Date desc, Client", conn)
                End If
            End If
        End If

        da.Fill(ds, "Tickets")
        If (ds.Tables("Tickets").Rows.Count > 0) Then
            GVS.DataSource = ds
            GVS.DataBind()
            lbcount.Text = ds.Tables("Tickets").Rows.Count
            lberr.Text = ""
        Else
            GVS.DataSource = Nothing
            GVS.DataBind()
            lbcount.Text = "0"
            lberr.Text = "No Record(s) found..."
        End If
        conn.Close()

        Change_Color()

    End Sub

    Sub Change_Color()

        For Each row As GridViewRow In GVS.Rows
            Dim WI1 As TextBox = DirectCast(row.Cells(4).FindControl("tbwi1"), TextBox)

            Dim TPR, TStat As String
            TPR = WI1.Text
            TStat = row.Cells(5).Text

            If TPR = "NORMAL" Then
                WI1.BackColor = Color.FromName("#d5f6e5")
                WI1.ForeColor = Color.FromName("#059d4e")
            ElseIf TPR = "MEDIUM" Then
                WI1.BackColor = Color.FromName("#fcddbe")
                WI1.ForeColor = Color.FromName("#c56503")
                row.Style.Add("text-decoration", "blink")
            ElseIf TPR = "URGENT" Then
                WI1.BackColor = Color.FromName("#f9d5d1")
                WI1.ForeColor = Color.FromName("#e74c3c")
                row.Style.Add("text-decoration", "blink")
            ElseIf TPR = "SOLVED" Then
                WI1.BackColor = Color.FromName("#d1e3fb")
                WI1.ForeColor = Color.FromName("#0f8af5")
                row.Style.Add("text-decoration", "blink")
            End If

            ' get client name from client id
            Dim ClID As String = row.Cells(2).Text
            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select Client_id, Client from Clients where Client_id='" & ClID & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows = True Then
                PDR.Read()
                row.Cells(2).Text = PDR.Item("client")
            End If
            PDR.Close()
            conn.Close()

            If row.Cells(4).Text = "URGENT" Then
                row.Cells(4).Text = "<blink>" & row.Cells(4).Text.ToString() & "</blink>"
            End If

        Next
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try

            Ticket_Data()

        Catch ex As Exception
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GVS_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles GVS.PageIndexChanging
        Try
            Ticket_Data()
            GVS.PageIndex = e.NewPageIndex
            GVS.DataBind()
            Change_Color()
            Exit Sub
        Catch ex As Exception
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GVS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GVS.SelectedIndexChanged
        Try
            Dim row As GridViewRow = GVS.SelectedRow
            Dim TID As String = row.Cells(0).Text
            Dim TSTS As String = row.Cells(4).Text

            If TSTS = "PENDING" Then
                Response.Redirect("assign_ticket.aspx?TID=" & TID)
            Else
                Response.Redirect("ticket_details.aspx?TID=" & TID)
            End If

            Exit Sub
        Catch ex As Exception
            lberr.Text = ex.Message
        End Try
    End Sub

    'Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
    '    If e.Row.RowType = DataControlRowType.DataRow Then
    '        Dim TPR As String = e.Row.Cells(6).Text
    '        Dim TStat As String = e.Row.Cells(7).Text

    '        'CornflowerBlue, LightGreen, Gold, OrangeRed
    '        For Each cell As TableCell In e.Row.Cells
    '            If TPR = "NORMAL" And TStat = "OPEN" Then
    '                e.Row.Cells(7).BackColor = Color.FromName("#a0f8b5")
    '                e.Row.Cells(6).ForeColor = Color.FromName("#222222")
    '            ElseIf TPR = "NEW" And TStat = "OPEN" Then
    '                e.Row.BackColor = Color.FromName("PowderBlue")
    '                e.Row.Cells(6).ForeColor = Color.FromName("#222222")
    '            ElseIf TPR = "URGENT" And TStat = "OPEN" Then
    '                e.Row.BackColor = Color.FromName("#f5e9a6") 'Color.FromName("#fbf5b2")
    '                e.Row.Cells(6).ForeColor = Color.FromName("#222222")
    '                e.Row.Style.Add("text-decoration", "blink")
    '            ElseIf TPR = "VERY URGENT" And TStat = "OPEN" Then
    '                e.Row.BackColor = Color.FromName("#fa9975")
    '                e.Row.Cells(6).ForeColor = Color.FromName("#222222")
    '                e.Row.Style.Add("text-decoration", "blink")
    '            ElseIf TStat = "SOLVED" Then
    '                e.Row.BackColor = Color.FromName("#87cdf9")
    '                e.Row.Cells(6).ForeColor = Color.FromName("#222222")
    '                e.Row.Style.Add("text-decoration", "blink")
    '            End If
    '        Next
    '    End If
    'End Sub


    'Private Sub GVS_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GVS.RowDataBound
    '    If e.Row.RowType = DataControlRowType.DataRow Then

    '        If e.Row.Cells(6).Text = "NORMAL" Then
    '            e.Row.BackColor = Color.FromName("#cafcd7")
    '            e.Row.Cells(6).ForeColor = Color.DarkGreen

    '            e.Row.Cells(6).Text = "<blink>" & e.Row.Cells(6).Text.ToString() & "</blink>"
    '            'e.Row.Cells(2).ForeColor = Color.Red
    '            'e.Row.BackColor = System.Drawing.Color.Yellow
    '        End If
    '    End If
    'End Sub

    Private Sub btnall_Click(sender As Object, e As EventArgs) Handles btnall.Click
        Try

            tbsearch.Text = ""
            Ticket_Data()

            Exit Sub
        Catch ex As Exception
            lberr.Text = ex.Message
        End Try
    End Sub

End Class
