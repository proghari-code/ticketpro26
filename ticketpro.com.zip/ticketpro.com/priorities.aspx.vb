﻿
Partial Class priorities
    Inherits System.Web.UI.Page

End Class
