﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class logout
    Inherits System.Web.UI.Page

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            ' Insert user log in to table 
            conn.Open()
            ds = New Data.DataSet
            da = New SqlDataAdapter("Insert into Userlog (Username, UserType, PCname, UserIP, LogTime, LogStatus) values ('" & Session("userid") & "','" & Session("usertype") & "','ADMIN','ADMIN','" & Now & "','LOGOUT')", conn)
            da.Fill(ds, "Userlog")
            conn.Close()

            Response.Cookies("hssptuser").Value = ""
            Response.Cookies("hssptuser").Expires = DateTime.Now
            Response.Cookies("hssptuspwd").Value = ""
            Response.Cookies("hssptuspwd").Expires = DateTime.Now

            Response.Cookies("auser").Value = ""
            Response.Cookies("auser").Expires = DateTime.Now
            Response.Cookies("auspwd").Value = ""
            Response.Cookies("auspwd").Expires = DateTime.Now

            Session("userid") = ""
            Session("staffname") = ""
            Session("fullname") = ""
            Session("usertype") = ""
            Session("branchid") = ""

            Session.Clear()
            Response.Redirect("default.aspx")

        Catch ex As Exception
            'lberr.Text = ex.Message
        End Try
    End Sub
End Class
