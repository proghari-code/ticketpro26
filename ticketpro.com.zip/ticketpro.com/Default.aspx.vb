﻿Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Net
Imports System.Net.WebRequestMethods
Imports System.Security
Imports System.Security.Cryptography

Partial Class _Default
    Inherits System.Web.UI.Page
    Dim NOL As Decimal ' to get number of login for a user

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset
    Dim ipaddress As String
    Dim PreviousPageName As String
    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            'Session("userid") = ""
            'Session("staffname") = ""
            'Session.Clear()

            If Not Page.IsPostBack Then

                ' get local ip 
                ipaddress = Request.ServerVariables("HTTP_X_FORWARDED_FOR")
                If ipaddress = "" Or ipaddress Is Nothing Then
                    ipaddress = Request.ServerVariables("REMOTE_ADDR")
                End If
                lbip.Text = lbip.Text & ipaddress
                tbuser.Text = ""
                tbpwd.Text = ""


                Panel1.Visible = False
                Panel2.Visible = False

                ' Code for get previous page and redirect after logged in start
                'If (Not (Request.UrlReferrer) Is Nothing) Then
                '    PreviousPageName = Request.UrlReferrer.Segments((Request.UrlReferrer.Segments.Length - 1))
                '    Session("prepage") = PreviousPageName
                'End If


                If Request.Cookies("hssptuser") Is Nothing Or Request.Cookies("hssptuspwd") Is Nothing Then
                    tbuser.Text = ""
                    tbpwd.Text = ""
                    tmrcookies.Enabled = False
                    Exit Sub
                Else
                    tmrcookies.Interval = 500
                End If
                ' cookeis end
                tbuser.Focus()

            End If
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Try
            If tbuser.Text = "" Or tbpwd.Text = "" Then
                Panel1_on()
                lberr.Text = "Please check the Username and Password"
                Exit Sub
            End If

            ' check if any user login 
            If Session("userid") <> "" Then
                Session("userid") = ""
                Session("staffname") = ""
                Session("fullname") = ""
                Session("usertype") = ""
                Session.Clear()
                Response.Redirect("default.aspx")
                Exit Sub
            End If




            ' check the user's email id for not duplication
            Dim UPWD As String
            UPWD = Encrypt(tbpwd.Text.Trim)
            'UPWD = tbpwd.Text.Trim
            Dim uty, SName, Estat As String
            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Account Where username='" & Trim(tbuser.Text) & "' and Password='" & UPWD & "'"
            PDR = PCMD.ExecuteReader
            PDR.Read()
            If PDR.HasRows Then
                'get the staff name from the tbluserlogin table
                SName = PDR.Item("Name")
                uty = PDR.Item("Utype")
                Estat = PDR.Item("UStatus")
                ' Add number of login count 
                ' Get number of login in to a variable
                NOL = PDR.Item("NoOfLogin") + 1

                If Estat = "ACTIVE" Then
                    Session("uemail") = PDR.Item("Email")
                    Session("userid") = Trim(tbuser.Text)
                    Session("fullname") = PDR.Item("Name")
                    Session("usertype") = uty
                    Session("company") = PDR.Item("company")
                    Session("branchid") = PDR.Item("branchID")


                    PDR.Close()
                    conn.Close()

                    ' Update number of login in to Account table 
                    conn.Open()
                    ds = New Data.DataSet
                    da = New SqlDataAdapter("Update Account set NoOfLogin='" & NOL & "', LastLogin='" & Now & "' where UserName='" & Session("userid") & "'", conn)
                    da.Fill(ds, "Account")
                    conn.Close()



                    ' update browser details 
                    ' get browser details 
                    Dim BName, BVer, Btype, Bmobile, Bcookies, SEOCrawler, PCName, LDate As String
                    Dim objBrwInfo As HttpBrowserCapabilities = Request.Browser
                    BName = objBrwInfo.Browser
                    BVer = objBrwInfo.Version
                    Btype = objBrwInfo.Type
                    Bmobile = objBrwInfo.IsMobileDevice.ToString()
                    Bcookies = objBrwInfo.Cookies.ToString()
                    SEOCrawler = objBrwInfo.Crawler.ToString()
                    PCName = Environment.MachineName
                    LDate = Format(Now, "yyyy-MM-dd")

                    ' Insert user log in to table 
                    conn.Open()
                    ds = New Data.DataSet
                    '                                                                                                                                                                                                   Username,                   UserType,                 PCname,         UserIP,             LogDate,        LogTime,    LogStatus      Browser,        BVersion,       BrowserType,    Cookies,        MobileBrowser,          SEOCrawler
                    da = New SqlDataAdapter("Insert into Userlog (Username, UserType, PCname, UserIP, LogDate, LogTime, LogStatus, Browser, BVersion, BrowserType, Cookies, MobileBrowser, SEOCrawler) values ('" & Session("userid") & "','" & Session("usertype") & "','" & PCName & "','" & lbip.Text & "','" & LDate & "','" & CDate(Now) & "','LOGIN','" & BName & "','" & BVer & "','" & Btype & "','" & Bcookies & "','" & Bmobile & "','" & SEOCrawler & "')", conn)
                    da.Fill(ds, "Userlog")
                    conn.Close()
                    'update browser details ends

                    ' Encrypt and store cookies for future login starts
                    If cbrem.Checked = True Then
                        Response.Cookies("hssptuser").Value = ""
                        Response.Cookies("hssptuser").Expires = DateTime.Now
                        Response.Cookies("hssptuspwd").Value = ""
                        Response.Cookies("hssptuspwd").Expires = DateTime.Now

                        Dim SKEY As String = "PBSSB26@!"
                        Dim DIDenc, SCombine, Dpwdenc, SCombine1 As String

                        SCombine = tbuser.Text & SKEY
                        SCombine1 = tbpwd.Text & SKEY
                        DIDenc = Base64Encode(SCombine)
                        Dpwdenc = Base64Encode(SCombine1)

                        Response.Cookies("hssptuser").Value = DIDenc
                        Response.Cookies("hssptuspwd").Value = Dpwdenc
                        Response.Cookies("hssptuser").Expires = DateTime.Now.AddMonths(6)
                        Response.Cookies("hssptuspwd").Expires = DateTime.Now.AddMonths(6)
                    End If
                    ' Encrypt and store cookies for future login ends

                    ' get the previous session details and redirect the users accordingly
                    ' get the current active batch 
                    'Get_Current_Batch()

                    conn.Open()
                    PCMD.Connection = conn
                    PCMD.CommandText = "Select Username, url_name from Session_mgmt Where username='" & Trim(tbuser.Text) & "' order by id desc"
                    PDR = PCMD.ExecuteReader
                    PDR.Read()
                    If PDR.HasRows Then
                        Dim RDurl As String
                        RDurl = PDR.Item("url_name")
                        PDR.Close()
                        conn.Close()
                        'get the staff name from the tbluserlogin table
                        Response.Redirect(RDurl)
                    Else
                        PDR.Close()
                        conn.Close()
                        Response.Redirect("dashboard.aspx?nts=1&usr=local-1&ln=en&cn=my")
                        'Response.Redirect("index.html?usr=local-1&ln=en&cn=my")
                    End If


                    '' check if the user comes from any existing page or new login 
                    'Dim PrePage As String
                    'If Session("prepage") = "" Then
                    '    PrePage = Session("prepage")
                    '    If PrePage = "Default.aspx" Then
                    '        Response.Redirect("dashboard.aspx?usr=local-1&ln=en&cn=my")
                    '    Else
                    '        Session("prepage") = ""
                    '        Session("itemcode") = ""
                    '        Response.Redirect(PrePage)
                    '    End If
                    'Else

                    'End If


                Else
                    Panel1_on()
                    lberr.Text = "Your Not Allowed to login, Please Contact Administrator, Thank you..."
                    'Response.Write("<script>alert('Your Not Allowed to login, Please Contact Administrator, Thank you...')</script>")
                End If
            Else
                Panel1_on()
                lberr.Text = "Username or Password is Invalid or You may be a Customer"
                'Response.Write("<script>alert('Username or Password is Invalid and Your Not Allowed to login, Please Contact Administrator, Thank you......')</script>")
            End If
            PDR.Close()
            conn.Close()

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Get_Current_Batch()
        'conn.Open()
        'PCMD.Connection = conn
        'PCMD.CommandText = "Select Batchname from Batch order by id"
        'PDR = PCMD.ExecuteReader
        'PDR.Read()
        'If PDR.HasRows = False Then
        '    Session("batchname") = "Batch 2"
        '    PDR.Close()
        '    conn.Close()
        '    Exit Sub
        'Else
        '    Session("batchname") = PDR.Item("batchname")
        '    PDR.Close()
        '    conn.Close()
        'End If
    End Sub

    Private Sub tmrcookies_Tick(sender As Object, e As EventArgs) Handles tmrcookies.Tick
        Try

            'tmrcookies.Interval = Nothing
            tmrcookies.Enabled = False

            Response.Cookies("auser").Value = ""
            Response.Cookies("auser").Expires = DateTime.Now
            Response.Cookies("auspwd").Value = ""
            Response.Cookies("auspwd").Expires = DateTime.Now

            Response.Cookies("hssptuser").Value = ""
            Response.Cookies("hssptuser").Expires = DateTime.Now
            Response.Cookies("hssptuspwd").Value = ""
            Response.Cookies("hssptuspwd").Expires = DateTime.Now

            Dim UsID, Uspwd, ADcrypt, SKEY, ADcrypt1 As String
            SKEY = "HssPT25@!"
            If IsNothing(Context.Request.Cookies("hssptuser")) Then
                'If IsDBNull(Request.Cookies("auser").Value) <> True Then
                If Request.Cookies("hssptuser").Value = "" Or Request.Cookies("hssptuspwd").Value = "" Then

                End If
                Exit Sub
            End If
            Dim UIDOri As String = Request.Cookies("hssptuser").Value
            Dim UPWDOri1 As String = Request.Cookies("hssptuspwd").Value

            Dim L, L1 As Integer
            ADcrypt = Base64Decode(UIDOri)
            L = Len(ADcrypt)
            UsID = Left(ADcrypt, (L - 13))

            ADcrypt1 = Base64Decode(UPWDOri1)
            L1 = Len(ADcrypt1)
            Uspwd = Left(ADcrypt1, (L1 - 13))

            tbuser.Text = UsID
            'tbpwd.TextMode = TextBoxMode.SingleLine
            tbpwd.Text = Uspwd
            cbrem.Checked = True
            If Me.IsPostBack Then
                tbpwd.Attributes("value") = tbpwd.Text
            End If
            'tbpwd.TextMode = TextBoxMode.Password
            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Private Sub tbuser_TextChanged(sender As Object, e As EventArgs) Handles tbuser.TextChanged
        Try

            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Account Where username='" & Trim(tbuser.Text) & "'"
            PDR = PCMD.ExecuteReader
            PDR.Read()
            If PDR.HasRows = False Then
                Panel1_on()
                lbuser.Text = "Given User name not found..."
                PDR.Close()
                conn.Close()
                Exit Sub
            Else
                tbpwd.Focus()
                lbuser.Text = ""
                PDR.Close()
                conn.Close()
            End If

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Private Sub tmrtext_Tick(sender As Object, e As EventArgs) Handles tmrtext.Tick
        Try

            tmrtext.Enabled = False
            tbpwd.TextMode = TextBoxMode.Password

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Public Shared Function Base64Encode(ByVal plainText As String) As String
        Dim plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText)
        Return System.Convert.ToBase64String(plainTextBytes)
    End Function

    Public Shared Function Base64Decode(ByVal base64EncodedData As String) As String
        Dim base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData)
        Return System.Text.Encoding.UTF8.GetString(base64EncodedBytes)
    End Function

    Private Function Encrypt(clearText As String) As String
        Dim EncryptionKey As String = "PBSSB26@!"
        Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)
        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
           &H65, &H64, &H76, &H65, &H64, &H65,
           &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Convert.ToBase64String(ms.ToArray())
            End Using
        End Using
        Return clearText
    End Function


    Sub Panel1_on()
        Panel1.Visible = True
        Panel2.Visible = False
    End Sub
    Sub Panel2_on()
        Panel1.Visible = False
        Panel2.Visible = True
    End Sub

End Class

