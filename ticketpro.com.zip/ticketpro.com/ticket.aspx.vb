﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IdentityModel.Metadata
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Runtime.Remoting.Lifetime

Partial Class ticket
    Inherits System.Web.UI.Page

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("userid") = "" Then
                    Response.Redirect("default.aspx")
                End If

                ' Update session details for the current users 
                ' So that When the user ligin next time, they can continue where they left.
                Dim SesDate As String = Format(Now, "yyyy-MM-dd")
                conn.Open()
                ds = New Data.DataSet
                da = New SqlDataAdapter("Insert into Session_mgmt (Username, UserType, url_name, LogDate) values ('" & Session("userid") & "','" & Session("usertype") & "','ticket.aspx','" & SesDate & "')", conn)
                da.Fill(ds, "Session_mgmt")
                conn.Close()


                Panel1.Visible = False
                Panel2.Visible = False

                ' Add Categories to dropdown
                Product_Category_Data()
                ddcat.Items.Insert(0, New ListItem("Select...", "-1"))

                ' Bind Departments
                Department_Data()
                dddept.Items.Insert(0, New ListItem("Select...", "-1"))

                ' Generate Ticket ID for each time form loads
                Generate_TicketID()

                'get user name and company name
                tbby.Text = Session("fullname")
                tbcompany.Text = Session("company")
            End If

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Clear_Text()
        tbtid.Text = ""
        tbdate.Text = ""
        tbremarks.Text = ""
    End Sub

    Protected Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            If tbsubject.Text = "" Then
                Panel1_on()
                lberr.Text = "Please enter subject and Try again..."
                Exit Sub
            End If
            If dddept.Text = "-1" Then
                Panel1_on()
                lberr.Text = "Please select department to continue..."
                Exit Sub
            End If
            If ddcat.Text = "-1" Then
                Panel1_on()
                lberr.Text = "Please select category and try again..."
                Exit Sub
            End If
            If tbtid.Text = "" Or tbdate.Text = "" Or tbremarks.Text = "" Then
                Panel1_on()
                lberr.Text = "Please enter Remarks And Select Priority level..."
                Exit Sub
            End If

            Dim TicketTime As String = Now.ToString("T")
            Dim DtToday As String = Format(Now, "yyyy-MM-dd")

            ' Check if the ID exists
            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Tickets where TicketID='" & tbtid.Text & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows = True Then
                PDR.Close()
                conn.Close()
                Generate_TicketID()
            End If
            PDR.Close()
            conn.Close()
            ' ends

            ' get the client id by name 
            Dim CLID As String
            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select Client_id, Client from Clients where Client='" & tbcompany.Text & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows = True Then
                PDR.Read()
                CLID = PDR.Item("Client_id")
            Else
                Panel1_on()
                lberr.Text = "Client not found..."
                PDR.Close()
                conn.Close()
                Exit Sub
            End If
            PDR.Close()
            conn.Close()

            conn.Open()
            ds = New Data.DataSet
            '                                                                                                                                           TicketID,           Date,             Time,              Createdby,                             Client,                                 Category,           Remarks,                Priority,           Status
            da = New SqlDataAdapter("INSERT INTO Tickets (TicketID, Date, Time, Createdby, Client, Category, Remarks, Priority, Status) values ('" & tbtid.Text & "','" & DtToday & "','" & TicketTime & "','" & Session("userid").ToString & "','" & tbcompany.Text & "','" & ddcat.Text & "','" & tbremarks.Text & "','" & ddstatus.Text & "','OPEN')", conn)
            da.Fill(ds, "Tickets")
            ds.Dispose()
            conn.Close()

            Clear_Text()

            Generate_TicketID()


            Panel2_on()
            lberr1.Text = "Tickets Details Successfully Created, You will be notified..."

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Product_Category_Data()
        conn.Open()
        ds = New Data.DataSet
        da = New SqlDataAdapter("Select * from Category order by Category", conn)
        da.Fill(ds, "Category")
        If (ds.Tables("Category").Rows.Count > 0) Then
            ddcat.DataSource = ds
            ddcat.DataBind()
            lberr.Text = ""
        Else
            ddcat.DataSource = Nothing
            ddcat.DataBind()
            Panel1_on()
            lberr.Text = "No Record(s) found..."
        End If
        conn.Close()
    End Sub

    Sub Department_Data()
        conn.Open()
        ds = New Data.DataSet
        da = New SqlDataAdapter("Select * from Departments order by Department", conn)
        da.Fill(ds, "Departments")
        If (ds.Tables("Departments").Rows.Count > 0) Then
            dddept.DataSource = ds
            dddept.DataBind()
            lberr.Text = ""
        Else
            dddept.DataSource = Nothing
            dddept.DataBind()
            Panel1_on()
            lberr.Text = "No Record(s) found..."
        End If
        conn.Close()
    End Sub

    Sub Generate_TicketID()
        ' Generate Random Order ID
        Dim alphabets As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        Dim small_alphabets As String = "abcdefghijklmnopqrstuvwxyz"
        Dim numbers As String = "1234567890"

        Dim characters As String = numbers
        'If rbType.SelectedItem.Value = "1" Then
        '  characters += Convert.ToString(alphabets & small_alphabets) & numbers
        'End If
        Dim length As Integer = Integer.Parse(10)
        Dim otp As String = String.Empty
        For i As Integer = 0 To length - 1
            Dim character As String = String.Empty
            Do
                Dim index As Integer = New Random().Next(0, characters.Length)
                character = characters.ToCharArray()(index).ToString()
            Loop While otp.IndexOf(character) <> -1
            otp += character
        Next

        tbtid.Text = otp
        tbdate.Text = Format(Now, "yyyy-MM-dd")
    End Sub

    Sub Panel1_on()
        Panel1.Visible = True
        Panel2.Visible = False
    End Sub
    Sub Panel2_on()
        Panel1.Visible = False
        Panel2.Visible = True
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try

            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Tickets where TicketID='" & tbsearch.Text & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows Then
                PDR.Read()
                'TicketID, Date, Time, Createdby, Client, subject, Department, Category, Remarks, Priority, Status, updatedby, updated_date

                tbtid.Text = PDR.Item("TicketID")
                tbdate.Text = PDR.Item("Date")
                tbby.Text = PDR.Item("Createdby")
                tbcompany.Text = PDR.Item("Client")
                tbsubject.Text = PDR.Item("subject")
                ddcat.Text = PDR.Item("Category")
                dddept.Text = PDR.Item("Department")
                tbremarks.Text = PDR.Item("Remarks")
                ddstatus.Text = PDR.Item("status")
                If IsDBNull(PDR.Item("updatedby")) Then
                    lbuby.Text = "NEW"
                Else
                    lbuby.Text = PDR.Item("updatedby")
                End If


            Else
                PDR.Close()
                conn.Close()
                Panel1_on()
                lberr.Text = "Client Details Not found..."
                Exit Sub
            End If
            PDR.Close()
            conn.Close()

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub
End Class
