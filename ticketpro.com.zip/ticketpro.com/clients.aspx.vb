﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Net
Imports System.Net.Mail
Imports System.Security.Cryptography
Imports System.Diagnostics

Partial Class clients
    Inherits System.Web.UI.Page

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("userid") = "" Then
                    Response.Redirect("default.aspx")
                End If

                ' Update session details for the current users 
                ' So that When the user ligin next time, they can continue where they left.
                Dim SesDate As String = Format(Now, "yyyy-MM-dd")
                conn.Open()
                ds = New Data.DataSet
                da = New SqlDataAdapter("Insert into Session_mgmt (Username, UserType, url_name, LogDate) values ('" & Session("userid") & "','" & Session("usertype") & "','clients.aspx','" & SesDate & "')", conn)
                da.Fill(ds, "Session_mgmt")
                conn.Close()

                Panel1.Visible = False
                Panel2.Visible = False

                Bind_Data()

                tbfd.Text = Format(Now, "yyyy/MM/dd")
                tbtd.Text = Format(Now, "yyyy/MM/dd")

                Bind_Client_Type()

            End If

            Exit Sub
        Catch ex As Exception
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Bind_Data()
        Dim CName As String = Request.QueryString("CLID")
        If CName = "" Then
            Clear_Text()
            btndelete.Visible = False
            Exit Sub
        End If
        conn.Open()
        PCMD.Connection = conn
        PCMD.CommandText = "Select * from Clients where Client_id='" & CName & "'"
        PDR = PCMD.ExecuteReader
        If PDR.HasRows Then
            PDR.Read()
            tbclient.Text = PDR.Item("Client")
            tbadd1.Text = PDR.Item("address1")
            tbadd2.Text = PDR.Item("address2")
            tbpostcode.Text = PDR.Item("postcode")
            ddstate.Text = PDR.Item("state")
            tbemail.Text = PDR.Item("email")
            tbcontactno.Text = PDR.Item("contactno")
            tbcontactperson.Text = PDR.Item("contactperson")
            If IsDBNull(PDR.Item("remarks")) Then
                tbremarks.Text = "NO"
            Else
                tbremarks.Text = PDR.Item("remarks")
            End If
            ddstatus.Text = PDR.Item("status")
            ddastatus.Text = PDR.Item("approvalstatus")
            ddtype.Text = PDR.Item("CLType")

        Else
            PDR.Close()
            conn.Close()
            Response.Write("<script>alert('Client Details Not found...')</script>")
            lberr.Text = ""
            Exit Sub
        End If
        PDR.Close()
        conn.Close()
    End Sub

    Sub Clear_Text()
        tbclient.Text = ""
        tbadd1.Text = ""
        tbadd2.Text = ""
        tbpostcode.Text = ""
        tbcontactno.Text = ""
        tbemail.Text = ""
        tbcontactperson.Text = ""
        tbremarks.Text = ""
    End Sub

    Sub Bind_Client_Type()
        conn.Open()
        ds = New Data.DataSet
        da = New SqlDataAdapter("Select * from ClientType order by CLType", conn)
        da.Fill(ds, "ClientType")
        If (ds.Tables("ClientType").Rows.Count > 0) Then
            ddtype.DataSource = ds
            ddtype.DataBind()
        Else
            ddtype.DataSource = Nothing
            ddtype.DataBind()
        End If
        conn.Close()
    End Sub

    Protected Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try

            If tbclient.Text = "" Or tbadd1.Text = "" Or tbpostcode.Text = "" Or ddstate.Text = "" Or tbemail.Text = "" Or tbcontactno.Text = "" Or tbcontactperson.Text = "" Then
                Panel1_on()
                lberr.Text = "All fields are Mandatory, Please fill it all..."
                Exit Sub
            End If
            Dim Faxno As String = "N/A"

            Dim DtToday As String = Format(Now, "yyyy-MM-dd")

            ' Check for Exixtence
            conn.Open()
            ds = New Data.DataSet
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Clients where email='" & tbemail.Text & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows Then
                PDR.Close()
                '                                               Date,                   Createdby,                            Client,  address1,                         address2,                      Postcode,                           State,                       email,                         contactno,                          contactperson,                                  fax,                bankdetails,                    , ContractSDate,                    ContractEDate                       remarks,                        status,                         approvalstatus
                da = New SqlDataAdapter("Update Clients set Date='" & DtToday & "', Createdby= '" & Session("userid").ToString & "', address1='" & tbadd1.Text & "', address2='" & tbadd2.Text & "', Postcode='" & tbpostcode.Text & "', state='" & ddstate.Text & "', email='" & tbemail.Text & "', contactno='" & tbcontactno.Text & "', contactperson='" & tbcontactperson.Text & "', fax='" & Faxno & "', bankdetails='N/A', ContractSDate='" & tbfd.Text & "', ContractEDate='" & tbtd.Text & "', remarks='" & tbremarks.Text & "', status='" & ddstatus.Text & "', approvalstatus='" & ddastatus.Text & "', CLType='" & ddtype.Text & "' where Client='" & tbclient.Text & "'", conn)
                da.Fill(ds, "Clients")
                conn.Close()
            Else
                PDR.Close()
                conn.Close()

                conn.Open()
                PCMD.Connection = conn
                PCMD.CommandText = "Select * from Clients where Client='" & tbclient.Text & "'"
                PDR = PCMD.ExecuteReader
                If PDR.HasRows Then
                    PDR.Close()
                    conn.Close()
                    Panel1_on()
                    lberr.Text = "Given Client Name Already Exist..."
                    Exit Sub
                End If
                PDR.Close()
                conn.Close()

                conn.Open()
                PCMD.Connection = conn
                PCMD.CommandText = "Select * from Clients where email ='" & tbemail.Text & "'"
                PDR = PCMD.ExecuteReader
                If PDR.HasRows Then
                    PDR.Close()
                    conn.Close()
                    Panel1_on()
                    lberr.Text = "Given E-Mail ID Already Exist..."
                    Exit Sub
                End If
                PDR.Close()
                conn.Close()
                '                                                                                                                                            Fclient,                   Faddress,           Fpostcode,              Fstate,                 Femail,             Fofficeno,              Ffaxno,             Fcontactperson

                ' Generate a new UUID (Guid)
                Dim myuuid As Guid = Guid.NewGuid()
                ' Convert the UUID to a string
                Dim my_uuid As String = myuuid.ToString()
                conn.Open()
                '                                                                                                                                                                                                                                              Date,               Createdby,                      Client_id,                  Client,                 address1,        address2,                  Postcode,               State,                  email,                  contactno,              contactperson,  bankdetails, ContractSDate,      ContractEDate,             remarks,                status,             approvalstatus,          CLType
                da = New SqlDataAdapter("INSERT INTO Clients (Date, Createdby, Client_id, Client, address1, address2, Postcode, State, email, contactno, contactperson, ContractSDate, ContractEDate, remarks, status, approvalstatus, CLType) values ('" & DtToday & "','" & Session("userid").ToString & "','" & my_uuid & "','" & tbclient.Text & "','" & tbadd1.Text & "','" & tbadd2.Text & "','" & tbpostcode.Text & "','" & ddstate.Text & "','" & tbemail.Text & "','" & tbcontactno.Text & "','" & tbcontactperson.Text & "','" & tbfd.Text & "','" & tbtd.Text & "','" & tbremarks.Text & "','" & ddstatus.Text & "','" & ddastatus.Text & "','" & ddtype.Text & "')", conn)
                da.Fill(ds, "Clients")
                ds.Dispose()
                conn.Close()

            End If

            Panel2_on()
            lberr1.Text = "Client Details Successfully Updated..."

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Try
            If tbclient.Text = "" Then
                Panel1_on()
                Response.Write("<script>alert('Select Client to Delete...')</script>")
                Exit Sub
            End If
            conn.Open()
            da = New SqlDataAdapter("Delete from Clients where Client='" & tbclient.Text & "'", conn)
            da.Fill(ds, "Clients")
            ds.Dispose()
            conn.Close()

            Clear_Text()
            Panel2_on()
            Response.Write("<script>alert('Client Details Successfully Removed...')</script>")

            Exit Sub
        Catch ex As Exception
            lberr.Text = ex.Message
        End Try
    End Sub

    Private Function Encrypt(clearText As String) As String
        Dim EncryptionKey As String = "PRO2026@TK"
        Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)
        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
           &H65, &H64, &H76, &H65, &H64, &H65,
           &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Convert.ToBase64String(ms.ToArray())
            End Using
        End Using
        Return clearText
    End Function

    Sub Panel1_on()
        Panel1.Visible = True
        Panel2.Visible = False
    End Sub
    Sub Panel2_on()
        Panel1.Visible = False
        Panel2.Visible = True
    End Sub

End Class
