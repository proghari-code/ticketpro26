﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class header
    Inherits System.Web.UI.UserControl
    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))
    Private Sub header_Load(sender As Object, e As EventArgs) Handles Me.Load
        'lbdate.Text = Format(Now, "dd, MMMM, yyyy")
        lbuser.Text = Session("fullname")
        lbtype.Text = Session("usertype")
        lbcompany.Text = Session("company")

        conn.Open()
        PCMD.Connection = conn
        PCMD.CommandText = "Select * from Account Where UserName='" & Session("userid") & "'"
        PDR = PCMD.ExecuteReader
        If PDR.HasRows = False Then
            PDR.Close()
            conn.Close()
            Exit Sub
        Else
            PDR.Read()
            If IsDBNull(PDR.Item("avatar")) Then
                imgavatar.ImageUrl = "assets\icons\profile.png"
            Else
                imgavatar.ImageUrl = PDR.Item("avatar")
            End If
        End If
        PDR.Close()
        conn.Close()

    End Sub
End Class
