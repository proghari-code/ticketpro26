﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Partial Class departments
    Inherits System.Web.UI.Page

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("userid") = "" Then
                    Response.Redirect("Default.aspx")
                End If

                ' Update session details for the current users 
                ' So that When the user ligin next time, they can continue where they left.
                Dim SesDate As String = Format(Now, "yyyy-MM-dd")
                conn.Open()
                ds = New Data.DataSet
                da = New SqlDataAdapter("Insert into Session_mgmt (Username, UserType, url_name, LogDate) values ('" & Session("userid") & "','" & Session("usertype") & "','departments.aspx','" & SesDate & "')", conn)
                da.Fill(ds, "Session_mgmt")
                conn.Close()

                Panel1.Visible = False
                Panel2.Visible = False

                Product_Department_Data()
                Clear_Text()
            End If

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click
        Try
            If tbcat.Text = "" Then
                Panel1_on()
                lberr.Text = "Department Required..."
                Exit Sub
            End If

            conn.Open()
            ds = New Data.DataSet
            da = New SqlDataAdapter("INSERT INTO Departments (Department) values ('" & UCase(tbcat.Text) & "')", conn)
            da.Fill(ds, "Departments")
            conn.Close()

            Product_Department_Data()
            Clear_Text()

            Panel2_on()
            lberr1.Text = "Department Updated..."

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Try
            If tbcat.Text = "" Then
                Panel1_on()
                lberr.Text = "Select Department to Delete..."
                Exit Sub
            End If

            conn.Open()
            ds = New Data.DataSet
            da = New SqlDataAdapter("Delete from Departments where Department ='" & tbcat.Text & "'", conn)
            da.Fill(ds, "Departments")
            conn.Close()

            Panel2_on()
            lberr1.Text = "Selected Department Successfully Deleted..."

            Product_Department_Data()
            Clear_Text()

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GVS_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles GVS.PageIndexChanging
        Try
            Product_Department_Data()
            GVS.PageIndex = e.NewPageIndex
            GVS.DataBind()
            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GVS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GVS.SelectedIndexChanged
        Try
            Dim row As GridViewRow = GVS.SelectedRow
            Dim RoID As String = row.Cells(0).Text

            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Departments Where ID='" & RoID & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows = False Then
                Panel1_on()
                lberr.Text = "Department Name Not Found..."
                PDR.Close()
                conn.Close()
                Clear_Text()
                Exit Sub
            Else
                PDR.Read()
                tbcat.Text = PDR.Item("Department")
            End If
            PDR.Close()
            conn.Close()

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Clear_Text()
        tbcat.Text = ""
    End Sub

    Protected Sub btnnew_Click(sender As Object, e As EventArgs) Handles btnnew.Click
        Try
            Clear_Text()

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Private Sub GVS_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GVS.RowDataBound
        Try
            e.Row.Cells(0).Visible = False

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try

            Product_Department_Data()

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Product_Department_Data()
        conn.Open()
        ds = New Data.DataSet
        If tbsearch.Text = "" Then
            da = New SqlDataAdapter("Select * from Departments order by Department", conn)
        Else
            da = New SqlDataAdapter("Select * from Departments where Department like '%" & tbsearch.Text & "%' order by Department", conn)
        End If
        da.Fill(ds, "Departments")
        If (ds.Tables("Departments").Rows.Count > 0) Then
            GVS.DataSource = ds
            GVS.DataBind()
            lbcount.Text = ds.Tables("Departments").Rows.Count
            lberr.Text = ""
        Else
            GVS.DataSource = Nothing
            GVS.DataBind()
            lbcount.Text = "0"
            Panel1_on()
            lberr.Text = "No Record(s) found..."
        End If
        conn.Close()
    End Sub
    Sub Panel1_on()
        Panel1.Visible = True
        Panel2.Visible = False
    End Sub
    Sub Panel2_on()
        Panel1.Visible = False
        Panel2.Visible = True
    End Sub

End Class
