﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Partial Class set_reminders_days
    Inherits System.Web.UI.Page

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("userid") = "" Then

                End If

                ' Update session details for the current users 
                ' So that When the user ligin next time, they can continue where they left.
                Dim SesDate As String = Format(Now, "yyyy-MM-dd")
                conn.Open()
                ds = New Data.DataSet
                da = New SqlDataAdapter("Insert into Session_mgmt (Username, UserType, url_name, LogDate) values ('" & Session("userid") & "','" & Session("usertype") & "','set_reminders_days.aspx','" & SesDate & "')", conn)
                da.Fill(ds, "Session_mgmt")
                conn.Close()

                Panel1.Visible = False
                Panel2.Visible = False

                Get_Days()

            End If

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click
        Try
            If tbdays.Text = "" Then
                Panel1_on()
                lberr.Text = "Enter Days..."
                Exit Sub
            End If

            conn.Open()
            ds = New Data.DataSet
            da = New SqlDataAdapter("Update RemindersDays set RemDays='" & tbdays.Text & "'", conn)
            da.Fill(ds, "RemindersDays")
            conn.Close()

            Panel2_on()
            lberr1.Text = "Reminders Days Updated..."

            Get_Days()

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Get_Days()
        conn.Open()
        PCMD.Connection = conn
        PCMD.CommandText = "Select * from RemindersDays"
        PDR = PCMD.ExecuteReader
        If PDR.HasRows = True Then
            PDR.Read()
            tbdays.Text = PDR.Item("RemDays")
        Else
            tbdays.Text = "15"
        End If
        PDR.Close()
        conn.Close()
    End Sub

    Sub Panel1_on()
        Panel1.Visible = True
        Panel2.Visible = False
    End Sub
    Sub Panel2_on()
        Panel1.Visible = False
        Panel2.Visible = True
    End Sub

End Class
