﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Partial Class view_clients
    Inherits System.Web.UI.Page

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("userid") = "" Then
                    Response.Redirect("default.aspx")
                End If

                ' Update session details for the current users 
                ' So that When the user ligin next time, they can continue where they left.
                Dim SesDate As String = Format(Now, "yyyy-MM-dd")
                conn.Open()
                ds = New Data.DataSet
                da = New SqlDataAdapter("Insert into Session_mgmt (Username, UserType, url_name, LogDate) values ('" & Session("userid") & "','" & Session("usertype") & "','useradmin.aspx','" & SesDate & "')", conn)
                da.Fill(ds, "Session_mgmt")
                conn.Close()

                Panel1.Visible = False
                Panel2.Visible = False

                Glient_Data()
            End If

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Glient_Data()

        conn.Open()
        ds = New Data.DataSet
        If tbsearch.Text = "" Then
            'Date, Createdby, Client, address1, address2, Postcode, State, email, contactno, contactperson, fax, bankdetails, remarks, status, approvalstatus
            da = New SqlDataAdapter("Select ID, Client, address1, email, contactno, contactperson, status, approvalstatus, CLType from Clients order by Client", conn)
        Else
            da = New SqlDataAdapter("Select ID, Client, address1, email, contactno, contactperson, status, approvalstatus, CLType from Clients where client like'%" & tbsearch.Text & "%' or email like'%" & tbsearch.Text & "%' or contactno like'%" & tbsearch.Text & "%' or CLType like'%" & tbsearch.Text & "%' or status  like'%" & tbsearch.Text & "%'order by Client", conn)
        End If

        da.Fill(ds, "Tblclient")
        If (ds.Tables("Tblclient").Rows.Count > 0) Then
            GVS.DataSource = ds
            GVS.DataBind()
            lbcount.Text = ds.Tables("Tblclient").Rows.Count
            lberr.Text = ""
        Else
            GVS.DataSource = Nothing
            GVS.DataBind()
            lbcount.Text = "0"
            Panel1_on()
            lberr.Text = "No Record(s) found..."
        End If
        conn.Close()
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try

            Glient_Data()

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GVS_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles GVS.PageIndexChanging
        Try
            Glient_Data()
            GVS.PageIndex = e.NewPageIndex
            GVS.DataBind()
            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GVS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GVS.SelectedIndexChanged
        Try
            Dim row As GridViewRow = GVS.SelectedRow
            Dim GID As String = row.Cells(3).Text
            Dim CUID As String

            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Clients where email ='" & GID & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows = True Then
                PDR.Read()
                CUID = PDR.Item("Client_id")
            Else
                Panel1_on()
                lberr.Text = "Given E-Mail ID Already Exist..."
                PDR.Close()
                conn.Close()
                Exit Sub
            End If
            PDR.Close()
            conn.Close()

            Response.Redirect("clients.aspx?CLID=" & CUID)

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Panel1_on()
        Panel1.Visible = True
        Panel2.Visible = False
    End Sub
    Sub Panel2_on()
        Panel1.Visible = False
        Panel2.Visible = True
    End Sub

    Private Sub GVS_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GVS.RowEditing
        Try
            Dim row As GridViewRow = GVS.SelectedRow
            Dim GID As String = row.Cells(3).Text
            Dim CUID As String

            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Clients where email ='" & GID & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows = True Then
                PDR.Read()
                CUID = PDR.Item("Client_id")
            Else
                Panel1_on()
                lberr.Text = "Given E-Mail ID Already Exist..."
                PDR.Close()
                conn.Close()
                Exit Sub
            End If
            PDR.Close()
            conn.Close()

            Response.Redirect("approve_clients.aspx?CLID=" & CUID)

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub
End Class
