﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Configuration
Imports System.Security.Cryptography
Imports System.Diagnostics
Imports System.Text.RegularExpressions


Partial Class useradmin
    Inherits System.Web.UI.Page

    Dim PCMD As New SqlCommand
    Dim PDR As SqlDataReader

    Dim RCMD As New SqlCommand
    Dim RDR As SqlDataReader

    Dim da As SqlDataAdapter    ' data adaptor 
    Dim ds As Data.DataSet      ' initialize datset

    Dim ADID As String ' User ID
    Dim conn As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("ConStr"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("userid") = "" Then
                    Response.Redirect("default.aspx")
                End If

                ' check permission
                Check_User_Permission()

                ' Update session details for the current users 
                ' So that When the user ligin next time, they can continue where they left.
                Dim SesDate As String = Format(Now, "yyyy-MM-dd")
                conn.Open()
                ds = New Data.DataSet
                da = New SqlDataAdapter("Insert into Session_mgmt (Username, UserType, url_name, LogDate) values ('" & Session("userid") & "','" & Session("usertype") & "','useradmin.aspx','" & SesDate & "')", conn)
                da.Fill(ds, "Session_mgmt")
                conn.Close()

                Panel1.Visible = False
                Panel2.Visible = False

                ' Bind Company Details 
                Bind_Company()

                Bind_Users()

                Clear_Text()

                tblastlogin.Text = Format(Now)

                ' Generate a new UUID (Guid)
                Dim myuuid As Guid = Guid.NewGuid()
                ' Convert the UUID to a string
                Dim my_uuid As String = myuuid.ToString()
                tbstaffid.Text = my_uuid
            End If

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btupdate_Click(sender As Object, e As EventArgs) Handles btupdate.Click
        Try

            If tbuser.Text = "" Then
                Panel1_on()
                lberr.Text = "User Name Required..."
                Exit Sub
            End If
            If tbname.Text = "" Then
                Panel1_on()
                lberr.Text = "Full Name Required..."
                Exit Sub
            End If

            Dim result As String = PasswordValidator.ValidatePassword(tbpwd.Text)
            Panel1_on()
            lberr.Text = result
            If lberr.Text <> "Password is valid." Then
                Exit Sub
            End If

            'If tbpwd.Text = "" Or tbcpwd.Text = "" Or Len(tbpwd.Text) <= 8 Then
            '    Panel1_on()
            '    lberr.Text = "Both Password Required and Password Length more than 6 Charecters..."
            '    Exit Sub
            'End If
            'If tbpwd.Text <> tbcpwd.Text Then
            '    Panel1_on()
            '    lberr.Text = "Both Password Should be same..."
            '    Exit Sub
            'End If
            If tbemail.Text = "" Then
                Panel1_on()
                lberr.Text = "E-Mail ID Required..."
                Exit Sub
            End If

            Dim DID As String = tbemail.Text.Trim()
            Dim SKEY As String = "PBSSB26@!"
            Dim CID, DIDenc, SCombine As String
            SCombine = DID & SKEY
            CID = Base64Encode(SCombine)
            DIDenc = Base64Encode(CID)

            Dim UPWD, UEMAIL As String
            UPWD = Encrypt(tbpwd.Text.Trim())
            UEMAIL = DIDenc

            ' get current date and time
            Dim TDate As String
            TDate = System.DateTime.Now

            conn.Open()
            ds = New Data.DataSet
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Account Where UserName='" & Trim(tbuser.Text) & "'"
            PDR = PCMD.ExecuteReader
            PDR.Read()
            If PDR.HasRows Then
                PDR.Close()
                '                                           Name,       UserName,       Password,                Email,                         CreationDate,                LastLogin,                Utype,                            UStatus,                            StaffID                     branchID
                da = New SqlDataAdapter("Update Account set Name='" & tbname.Text & "', Password='" & UPWD & "', Email='" & UEMAIL & "', CreationDate='" & TDate & "', LastLogin='" & TDate & "', Utype='" & ddutype.Text & "', Ustatus='" & ddstatus.Text & "', unique_id='" & tbstaffid.Text & "', company='" & ddcompany.Text & "' where UserName='" & tbuser.Text & "'", conn)
            Else
                PDR.Close()
                RCMD.Connection = conn
                RCMD.CommandText = "Select * from Account Where email='" & tbemail.Text & "'"
                RDR = RCMD.ExecuteReader
                If RDR.HasRows Then
                    Panel1_on()
                    lberr.Text = "Given E-Mail ID Already Exist..."
                    RDR.Close()
                    conn.Close()
                    Exit Sub
                End If
                RDR.Close()

                RCMD.Connection = conn
                RCMD.CommandText = "Select * from Account Where UserName='" & tbuser.Text & "'"
                RDR = RCMD.ExecuteReader
                If RDR.HasRows Then
                    Panel1_on()
                    lberr.Text = "Given User Name ID Already Exist..."
                    RDR.Close()
                    conn.Close()
                    Exit Sub
                End If
                RDR.Close()

                '                                                                                                                                                                   Name,                   UserName,           Password,       Email,          CreationDate,               LastLogin,         NoOfLogin, Utype,                    UStatus,            unique_id,                  company
                da = New SqlDataAdapter("INSERT INTO Account (Name, UserName, Password, Email, CreationDate, LastLogin, NoOfLogin, Utype, UStatus, unique_id, company) values ('" & UCase(tbname.Text) & "','" & tbuser.Text & "','" & UPWD & "','" & UEMAIL & "','" & TDate & "','" & tblastlogin.Text & "','0','" & ddutype.Text & "','" & ddstatus.Text & "','" & tbstaffid.Text & "','" & ddcompany.Text & "')", conn)
            End If
            PDR.Close()
            da.Fill(ds, "Account")
            conn.Close()

            Bind_Users()
            Clear_Text()

            Panel2_on()
            lberr1.Text = "User Detail Successfully Updated..."

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Bind_Company()
        conn.Open()
        ds = New Data.DataSet
        da = New SqlDataAdapter("Select Company from Company order by Company", conn)
        da.Fill(ds, "Company")
        If (ds.Tables("Company").Rows.Count > 0) Then
            ddcompany.DataSource = ds
            ddcompany.DataBind()
            lberr.Text = ""
        Else
            ddcompany.DataSource = Nothing
            ddcompany.DataBind()
            Panel1_on()
            lberr.Text = "No Record(s) found..."
        End If
        conn.Close()
    End Sub

    Sub Bind_Users()
        conn.Open()
        ds = New Data.DataSet
        If tbsearch.Text = "" Then
            da = New SqlDataAdapter("Select * from Account order by Name, Utype, UStatus", conn)
        Else
            da = New SqlDataAdapter("Select * from Account where name like'%" & tbsearch.Text & "%' or email like'%" & tbsearch.Text & "%' or Utype like'%" & tbsearch.Text & "%' or UStatus='" & tbsearch.Text & "' or company like'%" & tbsearch.Text & "%' order by Name, Utype, UStatus", conn)
        End If
        da.Fill(ds, "Account")
        If (ds.Tables("Account").Rows.Count > 0) Then
            GVC.DataSource = ds
            GVC.DataBind()
            lbcount.Text = ds.Tables("Account").Rows.Count
            lberr.Text = ""
        Else
            GVC.DataSource = Nothing
            GVC.DataBind()
            Panel1_on()
            lbcount.Text = 0
            lberr.Text = "No Record(s) found..."
        End If
        conn.Close()

    End Sub

    Protected Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Try
            If tbuser.Text = "" Then
                Panel1_on()
                lberr.Text = "Select User to Delete..."
                Exit Sub
            End If

            conn.Open()
            ds = New Data.DataSet
            da = New SqlDataAdapter("Delete from Account where UserName ='" & tbuser.Text & "'", conn)
            da.Fill(ds, "Account")
            conn.Close()

            Panel2_on()
            lberr1.Text = "User Detail Successfully Deleted..."

            Bind_Users()
            Clear_Text()

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GVC_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles GVC.PageIndexChanging
        Try
            Bind_Users()
            GVC.PageIndex = e.NewPageIndex
            GVC.DataBind()
            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GVC_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GVC.SelectedIndexChanged
        Try
            Dim row As GridViewRow = GVC.SelectedRow
            Dim UsrID As String = row.Cells(1).Text

            conn.Open()
            PCMD.Connection = conn
            PCMD.CommandText = "Select * from Account Where UserName='" & UsrID & "'"
            PDR = PCMD.ExecuteReader
            If PDR.HasRows = False Then
                Panel1_on()
                lberr.Text = "Given User Name Not Found..."
                PDR.Close()
                conn.Close()
                Clear_Text()
                Exit Sub
            Else
                PDR.Read()
                Dim TID, ADC, ADC1 As String
                Dim L As Integer
                ADC1 = Base64Decode(PDR.Item("Email"))
                ADC = Base64Decode(ADC1)
                L = Len(ADC)
                TID = Left(ADC, (L - 9))

                'Name, UserName, Password, Email, CreationDate, LastLogin, NoOfLogin, Utype, UStatus, StaffID
                tbuser.Text = PDR.Item("UserName")
                tbpwd.Text = PDR.Item("Password")
                tbcpwd.Text = PDR.Item("Password")
                tbname.Text = PDR.Item("Name")
                ddstatus.Text = PDR.Item("UStatus")
                ddutype.Text = PDR.Item("Utype")
                tbemail.Text = TID 'PDR.Item("Email")
                ddcompany.Text = PDR.Item("company")
            End If
            PDR.Close()
            conn.Close()

            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Sub Clear_Text()
        tbuser.Text = ""
        tbname.Text = ""
        tbpwd.Text = ""
        tbcpwd.Text = ""
        tbemail.Text = ""
    End Sub

    Private Function Encrypt(clearText As String) As String
        Dim EncryptionKey As String = "PBSSB26@!"
        Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)
        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
             &H65, &H64, &H76, &H65, &H64, &H65,
             &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Convert.ToBase64String(ms.ToArray())
            End Using
        End Using
        Return clearText
    End Function

    Protected Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try

            Bind_Users()

        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Private Property SortDirection As String
        Get
            Return IIf(ViewState("SortDirection") IsNot Nothing, Convert.ToString(ViewState("SortDirection")), "ASC")
        End Get
        Set(value As String)
            ViewState("SortDirection") = value
        End Set
    End Property

    Private Sub BindGrid(Optional ByVal sortExpression As String = Nothing)
        'Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        'Dim con As SqlConnection = New SqlConnection(constr)
        Dim cmd As SqlCommand
        If tbsearch.Text = "" Then
            cmd = New SqlCommand("Select * from Account order by Name, Utype, UStatus")
        Else
            cmd = New SqlCommand("Select * from Account where name like'%" & tbsearch.Text & "%' or email like'%" & tbsearch.Text & "%' or Utype like'%" & tbsearch.Text & "%' or UStatus='" & tbsearch.Text & "' order by Name, Utype, UStatus")
        End If
        'cmd = New SqlCommand("Select ID, Supplier, address1, address2, Postcode, State, email, offph, fax, mobileno, contactperson, ssmno, accno, bankname, terms, remarks, status from Suppliers where Supplier like'%" & tbsearch.Text & "%' or email like'%" & tbsearch.Text & "%' or mobileno like'%" & tbsearch.Text & "%' order by Suppliers, State")
        Dim sda As SqlDataAdapter = New SqlDataAdapter
        cmd.Connection = conn
        sda.SelectCommand = cmd
        Dim dt As DataTable = New DataTable
        sda.Fill(dt)
        If (Not (sortExpression) Is Nothing) Then
            Dim dv As DataView = dt.AsDataView
            Me.SortDirection = IIf(Me.SortDirection = "ASC", "DESC", "ASC")
            dv.Sort = sortExpression & " " & Me.SortDirection
            GVC.DataSource = dv
        Else
            GVC.DataSource = dt
        End If

        GVC.DataBind()
    End Sub

    Protected Sub OnSorting(ByVal sender As Object, ByVal e As GridViewSortEventArgs)
        Me.BindGrid(e.SortExpression)
    End Sub

    Protected Sub OnPageIndexChanging(sender As Object, e As GridViewPageEventArgs)
        GVC.PageIndex = e.NewPageIndex
        Me.BindGrid()
    End Sub

    Private Sub GVC_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles GVC.RowDeleting
        lberr.Text = "Del"
        tbsearch.Text = "Del"
    End Sub

    'Sub Check_User_Permission()
    '    Dim url, CurURL As String
    '    Dim SKEY As String = "HARI2023#$"
    '    url = HttpContext.Current.Request.Url.AbsolutePath
    '    Dim l1 As Integer
    '    l1 = Len(url)
    '    CurURL = Right(url, (l1 - 1))

    '    ' for decrypt
    '    Dim DID, CID, DIDenc, SCombine As String
    '    DID = CurURL
    '    SCombine = DID & SKEY
    '    CID = Base64Encode(SCombine)
    '    DIDenc = Base64Encode(CID)

    '    conn.Open()
    '    PCMD.Connection = conn
    '    PCMD.CommandText = "Select * from UserControl where UserName='" & Session("userid") & "' and page_name='" & DIDenc & "'"
    '    PDR = PCMD.ExecuteReader
    '    If PDR.HasRows = False Then
    '        PDR.Close()
    '        conn.Close()
    '        Response.Redirect("you_are_only_allowed.aspx")
    '    End If
    '    PDR.Close()
    '    conn.Close()
    'End Sub

    Public Shared Function Base64Encode(ByVal plainText As String) As String
        Dim plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText)
        Return System.Convert.ToBase64String(plainTextBytes)
    End Function

    Public Shared Function Base64Decode(ByVal base64EncodedData As String) As String
        Dim base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData)
        Return System.Text.Encoding.UTF8.GetString(base64EncodedBytes)
    End Function

    Sub Panel1_on()
        Panel1.Visible = True
        Panel2.Visible = False
    End Sub
    Sub Panel2_on()
        Panel1.Visible = False
        Panel2.Visible = True
    End Sub

    Sub Check_User_Permission()
        Try

            If Session("usertype") = "STAFF" Then
                Response.Redirect("usercontrol.aspx?requrl=Documents")
            End If


            Exit Sub
        Catch ex As Exception
            Panel1_on()
            lberr.Text = ex.Message
        End Try
    End Sub

    Public Class PasswordValidator
        Public Shared Function ValidatePassword(password As String) As String
            Dim errorMessage As String = ""

            ' Minimum length check
            If password.Length < 8 Then
                errorMessage &= "Password must be at least 8 characters long.<br/>"
            End If

            ' Uppercase check
            If Not Regex.IsMatch(password, "[A-Z]") Then
                errorMessage &= "Password must contain at least one uppercase letter.<br/>"
            End If

            ' Lowercase check
            If Not Regex.IsMatch(password, "[a-z]") Then
                errorMessage &= "Password must contain at least one lowercase letter.<br/>"
            End If

            ' Digit check
            If Not Regex.IsMatch(password, "[0-9]") Then
                errorMessage &= "Password must contain at least one digit.<br/>"
            End If

            ' Special character check
            If Not Regex.IsMatch(password, "[^a-zA-Z0-9]") Then
                errorMessage &= "Password must contain at least one special character.<br/>"
            End If

            If String.IsNullOrEmpty(errorMessage) Then
                Return "Password is valid."
            Else
                Return errorMessage
            End If
        End Function
    End Class


End Class

